@extends('welcome')
@section('contenido')

<div id="information-information" class="container">
    <ul class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i></a></li>
        <li><a href="/acerca_de">Acerca de </a></li>
    </ul>
    <div class="row">
        <div id="content" class="col-sm-12">
            <h1 class="heading text-center"><span>Acerca de nosotros </span><svg>
                    <use xlink:href="#headingsvg"></use>
                </svg></h1>
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <h3 style="text-transform: none;letter-spacing: 1px;font-size: 18px;">The standard Lorem Ipsum passage</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-2 col-lg-1 col-xs-2">
                    <img src="image/catalog/icon/thumb-up-button.png" style="width: 35px; height: 35px; float: left;">
                </div>
                <div class="col-sm-10 col-lg-11 col-xs-10">
                    <p style="font-size:14px;">An natum nulla eruditi mei, te qui idque adipisci, nonumy graeci has ad. Cu diam dolor noluisse nec. Nam ex dicta graeco, audire nominati persequeris eu eos. Pri nibh dolor soleat cu, sanctus inermis instructior eum ei. Scripta ceteros sit ex. Et eum alia laudem delectus.</p>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h3 style="text-transform: none;letter-spacing: 1px;font-size: 18px;">Aliquam vulputate, neque consectetur gravida egestas
                    </h3>
                </div>
                <div class="col-sm-2 col-lg-1 col-xs-2">
                    <img src="image/catalog/icon/front-bus.png" style="width: 35px; height: 35px; float: left;">
                </div>
                <div class="col-sm-10 col-lg-11 col-xs-10">
                    <p style="font-size:14px;">Et quis dictas meliore nec, habeo lorem blandit et vis, alia veniam assueverit an duo. Facilis offendit eleifend id has. Deserunt expetenda est an, tacimates iudicabit sed eu. Cum eu periculis similique, ut meis expetenda quo.&nbsp; Eam ea omnis fierent disputando.
                    </p>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h3 style="text-transform: none;letter-spacing: 1px;font-size: 18px;">Suspendisse vel lorem massa. Morbi
                    </h3>
                </div>
                <div class="col-sm-2 col-lg-1 col-xs-2">
                    <img src="image/catalog/icon/clipboard-paste-button.png" style="width: 35px; height: 35px; float: left;">
                </div>
                <div class="col-sm-10 col-lg-11 col-xs-10">
                    <p style="font-size:14px;">Eam eu illud menandri praesent, ei regione oporteat tractatos nam. Ad mea postea voluptua constituam, aeterno aperiri facilis et nec, utroque veritus no mea. Mel quando tantas accusamus et, quo quot augue senserit ex, possim efficiendi has no. Nam at bonorum prodesset, per ne primis platonem, mel in mundi salutatus constituto. Ei vis vidit oportere, no prima eripuit ius, vim at justo legendos.<br>
                    </p>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h3 style="text-transform: none;letter-spacing: 1px;font-size: 18px;">Vivamus ut diam ut risus sodales vestibulum eget varius dolor</h3>
                </div>
                <div class="col-sm-2 col-lg-1 col-xs-2">
                    <img src="image/catalog/icon/circles-extend-button.png" style="width: 35px; height: 35px; float: left;">
                </div>
                <div class="col-sm-10 col-lg-11 col-xs-10">
                    <p style="font-size:14px;">Has ut stet discere nonumes, te dicam nullam vim. Eam iriure tacimates persecuti ut. No labore reprimique consequuntur pri, iusto nihil ex usu. Ne illud definitionem pri, prima fuisset phaedrum sea cu. His ea partem tempor elaboraret, nam iudico atomorum accusamus ad, quo ut quidam aliquam voluptua. Cu cotidieque dissentiunt vix, at putent tamquam scribentur usu.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@stop
