<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('/principal/index');
});

Route::get('/registrarse', function () {
    return view('/principal/registrarse');
});

Route::get('/iniciar_sesion', function () {
    return view('/principal/iniciar_sesion');
});

Route::get('/acerca_de', function () {
    return view('/principal/acerca_de');
});

Route::get('/contacto', function () {
    return view('/principal/contacto');
});

Route::get('/contacto', function () {
    return view('/principal/contacto');
});

Route::get('/tienda', function () {
    return view('/principal/tienda');
});

Route::get('/info_producto', function () {
    return view('/principal/info_producto');
});

Route::get('/carrito', function () {
    return view('/principal/carrito');
});

Route::get('/pagar', function () {
    return view('/principal/pagar');
});